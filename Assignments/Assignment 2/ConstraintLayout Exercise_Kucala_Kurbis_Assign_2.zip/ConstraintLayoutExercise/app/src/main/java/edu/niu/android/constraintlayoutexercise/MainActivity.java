package edu.niu.android.constraintlayoutexercise;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
/************************************************************************
 *                                                                      *
 * CSCI 322/522 Assignment 2 Fall semester                              *
 *                                                                      *
 * App Name: ConstraintLayout Exercise                                  *
 *                                                                      *
 * Class Name: MainActivity.java                                        *
 *                                                                      *
 * Developer(s): Terry Kucala & Jake Kurbis                             *
 *                                                                      *
 * Due Date: 09/22/2023                                                 *
 *                                                                      *
 * Purpose: This is the main controller for the app                     *
 *                                                                      *
 ************************************************************************/
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}