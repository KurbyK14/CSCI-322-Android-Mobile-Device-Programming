package edu.niu.android.chessboard;

/************************************************************************
 *                                                                      *
 * CSCI 322/522 Assignment 7 Fall semester                              *
 *                                                                      *
 * App Name: chessboard                                                 *
 *                                                                      *
 * Class Name: MainActivity.java                                        *
 *                                                                      *
 * Developer(s): Terry Kucala & Jake Kurbis                             *
 *                                                                      *
 * Due Date: 12/08/2023                                                 *
 *                                                                      *
 * Purpose: This class is the main entry point for the chessboard app.  *
 * It handles the user interface setup, including the creation and      *
 * configuration of the chessboard layout based on screen orientation.  *
 * It also manages the interaction between the UI and the ChessModel.   *
 *                                                                      *
 ************************************************************************/

import android.content.res.Configuration;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.GridLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private ChessModel chessModel; // Instance of ChessModel to manage the state of the chessboard

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        chessModel = new ChessModel(); // Initialize the chess model on creation

        // Setup the UI based on the current orientation
        setupChessboardUI(getResources().getConfiguration().orientation);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        // Handle orientation changes and update the UI accordingly
        setupChessboardUI(newConfig.orientation);
    }

    private void setupChessboardUI(int orientation) {
        // Choose the layout based on the current orientation
        if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
            setContentView(R.layout.activity_chessboard_landscape); // Use landscape layout
        } else {
            setContentView(R.layout.activity_main); // Use portrait layout
        }

        GridLayout gridLayout = (GridLayout) findViewById(orientation == Configuration.ORIENTATION_LANDSCAPE ?
                R.id.chessboard_landscape : R.id.chessboard);
        gridLayout.removeAllViews(); // Clear any existing views from the grid

        // Calculate the total number of squares on the chessboard
        int totalSquares = ChessModel.BOARD_SIZE * ChessModel.BOARD_SIZE;
        gridLayout.setColumnCount(ChessModel.BOARD_SIZE); // Set the number of columns in the grid
        gridLayout.setRowCount(ChessModel.BOARD_SIZE); // Set the number of rows in the grid

        // Loop to add squares (TextViews) to the chessboard
        for (int i = 0; i < totalSquares; i++) {
            int row = i / ChessModel.BOARD_SIZE;
            int col = i % ChessModel.BOARD_SIZE;
            TextView squareView = createSquare(row, col, orientation);
            gridLayout.addView(squareView); // Add the square view to the grid layout
        }
    }

    private TextView createSquare(int row, int col, int orientation) {
        TextView squareView = new TextView(this);
        squareView.setLayoutParams(new GridLayout.LayoutParams(
                GridLayout.spec(row, GridLayout.FILL, 1f),
                GridLayout.spec(col, GridLayout.FILL, 1f))); // Set layout parameters for equal distribution
        squareView.setGravity(Gravity.CENTER); // Center the text in the TextView
        squareView.setTextSize(24); // Set the text size for the chess piece
        squareView.setTypeface(squareView.getTypeface(), Typeface.BOLD); // Make the chess piece text bold
        squareView.setText(chessModel.getPieceAt(row, col)); // Set the text to the chess piece

        // Set the background color based on the square's color and orientation
        int backgroundColor = chessModel.isSquareBlack(row, col)
                ? (orientation == Configuration.ORIENTATION_LANDSCAPE
                ? ContextCompat.getColor(this, R.color.chess_square_alternate_color)
                : ContextCompat.getColor(this, R.color.chess_square_black))
                : ContextCompat.getColor(this, android.R.color.white);
        squareView.setBackgroundColor(backgroundColor);

        // Set the text color for visibility based on the square's color
        int textColor = chessModel.isSquareBlack(row, col)
                ? ContextCompat.getColor(this, android.R.color.white)
                : ContextCompat.getColor(this, android.R.color.black);
        squareView.setTextColor(textColor);

        return squareView; // Return the fully configured TextView representing a chess square
    }
}