package edu.niu.android.chessboard;

/************************************************************************
 *                                                                      *
 * CSCI 322/522 Assignment 7 Fall semester                              *
 *                                                                      *
 * App Name: chessboard                                                 *
 *                                                                      *
 * Class Name: ChessModel.java                                          *
 *                                                                      *
 * Developer(s): Terry Kucala & Jake Kurbis                             *
 *                                                                      *
 * Due Date: 12/08/2023                                                 *
 *                                                                      *
 * Purpose: This class manages the chessboard's state, including        *
 * initializing the board, tracking piece positions, and determining    *
 * square colors. It serves as the central data model in the game's     *
 * layout.                                                              *
 *                                                                      *
 ************************************************************************/

public class ChessModel {
    // Define the size of the chessboard
    public static final int BOARD_SIZE = 8;

    // 2D array representing the chessboard, each cell holds a String representing a chess piece
    private String[][] board = new String[BOARD_SIZE][BOARD_SIZE];

    // Constructor to initialize the chessboard
    public ChessModel() {
        setupBoard();
    }

    // Method to set up the board with pieces in their initial positions
    private void setupBoard() {
        // Loop through each cell of the board and initialize them to an empty string
        for (int row = 0; row < BOARD_SIZE; row++) {
            for (int col = 0; col < BOARD_SIZE; col++) {
                board[row][col] = ""; // Set each cell to empty, indicating no piece
            }
        }

        // Setup Pawns on the board
        for (int col = 0; col < BOARD_SIZE; col++) {
            board[1][col] = "P"; // Place white pawns on the second row
            board[6][col] = "P"; // Place black pawns on the seventh row
        }

        // Setup Rooks on the board
        board[0][0] = board[0][7] = "R"; // Place white rooks at the corners of the first row
        board[7][0] = board[7][7] = "R"; // Place black rooks at the corners of the last row

        // Setup Knights on the board
        board[0][1] = board[0][6] = "N"; // Place white knights next to the rooks
        board[7][1] = board[7][6] = "N"; // Place black knights next to the rooks

        // Setup Bishops on the board
        board[0][2] = board[0][5] = "B"; // Place white bishops next to the knights
        board[7][2] = board[7][5] = "B"; // Place black bishops next to the knights

        // Setup Queens and Kings in the center
        board[0][3] = "Q"; // Place the white queen on the first row
        board[7][3] = "Q"; // Place the black queen on the last row
        board[0][4] = "K"; // Place the white king next to the white queen
        board[7][4] = "K"; // Place the black king next to the black queen
    }

    // Method to get the piece at a specific position on the board
    public String getPieceAt(int row, int col) {
        return board[row][col];
    }

    // Method to check if a square should be black based on its position
    public boolean isSquareBlack(int row, int col) {
        // Chessboard squares are black when the sum of row and column indices is odd
        return (row + col) % 2 != 0;
    }
}