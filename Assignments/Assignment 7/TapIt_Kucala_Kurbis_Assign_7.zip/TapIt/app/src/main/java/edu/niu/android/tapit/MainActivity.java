package edu.niu.android.tapit;

import androidx.appcompat.app.AppCompatActivity;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.widget.TextView;
import android.view.View;
import android.os.Bundle;

/************************************************************************
 *                                                                      *
 * CSCI 322/522 Assignment 7 Part B Fall semester                       *
 *                                                                      *
 * App Name: Tap It                                                     *
 *                                                                      *
 * Class Name: MainActivity.java                                        *
 *                                                                      *
 * Developer(s): Terry Kucala & Jake Kurbis                             *
 *                                                                      *
 * Due Date: 12/08/2023                                                 *
 *                                                                      *
 * Purpose: The purpose of this file is to create instances of          *
 *          the text views. It handles touch events and changes the     *
 *          color and tap count of the text views accordingly.          *
 *                                                                      *
 ************************************************************************/

public class MainActivity extends AppCompatActivity implements View.OnTouchListener {

    private TextView textViewColor;
    private TextView textViewTapCount;
    private GestureDetector detector;
    private int tapCount = 0;
    private boolean isBlue = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Initialize the views
        textViewColor = findViewById(R.id.textViewColorChange);
        textViewTapCount = findViewById(R.id.textViewTapCount);

        //Gesture detector
        DoubleTapHandler dth = new DoubleTapHandler();
        detector = new GestureDetector(this, dth);
        detector.setOnDoubleTapListener(dth);

        textViewColor.setOnTouchListener(this);
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        detector.onTouchEvent(event);
        return true;
    }

    private class DoubleTapHandler extends GestureDetector.SimpleOnGestureListener {

        //When a single tap, change the color to blue
        @Override
        public boolean onSingleTapConfirmed(MotionEvent e) {
            changeToBlue();
            return true;
        }

        //When a double tap, change the color to red
        @Override
        public boolean onDoubleTap(MotionEvent e) {
            changeToRed();
            return true;
        }

        //Check blue flag and change color to blue or just count the taps
        private void changeToBlue() {
            if (isBlue) {
                updateTapCount();
            }
            if (!isBlue) {
                textViewColor.setBackgroundColor(getResources().getColor(android.R.color.holo_blue_dark));
                isBlue = true;
                updateTapCount();
            }
        }

        ////Check blue flag and change color to red or just count the taps
        private void changeToRed() {
            if (isBlue) {
                textViewColor.setBackgroundColor(getResources().getColor(android.R.color.holo_red_light));
                isBlue = false;
                updateTapCount();
            }
            if (!isBlue) {
                updateTapCount();
            }
        }

        //Updates the tap counter and text inside the text view
        private void updateTapCount() {
            tapCount++;
            textViewTapCount.setText("Tap Count: " + tapCount);
        }
    }
}