package edu.niu.android.thisisfun;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

/************************************************************************
 *                                                                      *
 * CSCI 322/522 Assignment 1 Fall semester                              *
 *                                                                      *
 * App Name: This is Fun                                               *
 *                                                                      *
 * Class Name: MainActivity.java                                        *
 *                                                                      *
 * Developer(s): Terry Kucala & Jake Kurbis                             *
 *                                                                      *
 * Due Date: 09/15/2023                                                 *
 *                                                                      *
 * Purpose: This is the main controller for the app                     *
 *                                                                      *
 ************************************************************************/

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}