package edu.niu.android.emailcheckerapp;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.graphics.Point;
import android.view.View;

/************************************************************************
 *                                                                      *
 * CSCI 322/522 Assignment 4 Part 1 Fall semester                       *
 *                                                                      *
 * App Name: Email Checker App                                          *
 *                                                                      *
 * Class Name: MainActivity.java                                        *
 *                                                                      *
 * Developer(s): Terry Kucala & Jake Kurbis                             *
 *                                                                      *
 * Due Date: 10/20/2023                                                 *
 *                                                                      *
 * Purpose: The MainActivity class for the EmailChecker App acts as the *
 *          controller and manages the interactions between the user    *
 *          interface(EmailCheckerView) and the model(EmailChecker).    *
 *                                                                      *
 ************************************************************************/

public class MainActivity extends AppCompatActivity {
    private EmailChecker emailChecker;
    private EmailCheckerView emailCheckerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        // Get the size of the display.
        Point size = new Point();
        getWindowManager().getDefaultDisplay().getSize(size);
        int w = size.x / 2;

        emailChecker = new EmailChecker();
        emailCheckerView = new EmailCheckerView(this, w, new ButtonHandler());
        setContentView(emailCheckerView);
    }

    /**
     * This inner class acts as the onClick listener for the checkButton. When it is clicked,
     * it will retrieve the email entered by the user and checks if it's valid or invalid
     * by using the EmailChecker class and then updates the status on screen based on it's
     * results
     */
    private class ButtonHandler implements View.OnClickListener {
        public void onClick(View v) {
            String email = emailCheckerView.getEmail();
            boolean isValid = emailChecker.checkEmail(email);
            emailCheckerView.setStatusText(isValid ? "VALID" : "INVALID");
        }
    }

}