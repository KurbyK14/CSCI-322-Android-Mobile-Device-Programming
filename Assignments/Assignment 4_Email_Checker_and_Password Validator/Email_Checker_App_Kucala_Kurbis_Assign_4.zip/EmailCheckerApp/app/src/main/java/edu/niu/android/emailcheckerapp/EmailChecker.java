package edu.niu.android.emailcheckerapp;

/************************************************************************
 *                                                                      *
 * CSCI 322/522 Assignment 4 Part 1 Fall semester                       *
 *                                                                      *
 * App Name: Email Checker App                                          *
 *                                                                      *
 * Class Name: EmailChecker.java                                        *
 *                                                                      *
 * Developer(s): Terry Kucala & Jake Kurbis                             *
 *                                                                      *
 * Due Date: 10/20/2023                                                 *
 *                                                                      *
 * Purpose: The EmailChecker class provides the means to validate email *
 *          addresses. It checks for the presence of the '@' symbol     *
 *          followed by a '.', ensuring basic email structure           *
 *                                                                      *
 ************************************************************************/

public class EmailChecker {

    /**
     * Checks if the provided email is valid or invalid
     *
     * @param email: The email address to be checked
     *
     * @return true: If the email format is valid, false otherwise
     */
    public boolean checkEmail(String email) {

        if (email != null && !email.isEmpty()) {

            int atIndex = email.indexOf('@');
            int dotIndex = email.lastIndexOf('.');

            return atIndex >= 0 && dotIndex > atIndex;
        }
        return false;
    }
}