package edu.niu.android.emailcheckerapp;

import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.TextView;

/************************************************************************
 *                                                                      *
 * CSCI 322/522 Assignment 4 Part 1 Fall semester                       *
 *                                                                      *
 * App Name: Email Checker App                                          *
 *                                                                      *
 * Class Name: EmailCheckerView.java                                    *
 *                                                                      *
 * Developer(s): Terry Kucala & Jake Kurbis                             *
 *                                                                      *
 * Due Date: 10/20/2023                                                 *
 *                                                                      *
 * Purpose: The EmailCheckerView class is responsible for defining the  *
 *          user interface of the EmailChecker App. That includes the   *
 *          layout and behavior of the visual components like the email *
 *          field, check button, and status display                     *
 *                                                                      *
 ************************************************************************/


public class EmailCheckerView extends GridLayout {
    private Button checkButton;
    private EditText emailField;
    private TextView statusView;

    public EmailCheckerView(Context context, int w, OnClickListener listener) {
        super(context);

        // Set the row and column count
        setRowCount(3);
        setColumnCount(1);

        // Create the Button and setup layout parameters
        checkButton = new Button(context);
        LayoutParams lpButton = new LayoutParams();
        lpButton.width = LayoutParams.MATCH_PARENT;
        lpButton.height = LayoutParams.WRAP_CONTENT;

        // checkButton's characteristics
        checkButton.setLayoutParams(lpButton);
        checkButton.setText("CHECK EMAIL");
        checkButton.setBackgroundColor(Color.GREEN);
        checkButton.setTextColor(Color.WHITE);
        checkButton.setGravity(Gravity.CENTER);
        checkButton.setTextSize(35);
        checkButton.setOnClickListener(listener);

        // Create the EditText and setup layout parameters
        emailField = new EditText(context);
        Spec emailRowSpec = GridLayout.spec(1,1);
        Spec emailColumnSpec = GridLayout.spec(0, 1);
        LayoutParams lpEmail = new LayoutParams(emailRowSpec, emailColumnSpec);

        // emailField's characteristics
        emailField.setLayoutParams(lpEmail);
        emailField.setHint("Enter your email");
        emailField.setWidth(w + 2000);
        emailField.setTextSize(25);
        emailField.setGravity(Gravity.CENTER);
        emailField.setBackgroundColor(Color.WHITE);
        emailField.setTextColor(Color.DKGRAY);

        // Create TextView and set up layout parameters
        statusView = new TextView(context);
        Spec statusRowSpec = GridLayout.spec(2, 1);
        Spec statusColumnSpec = GridLayout.spec(0, 1);
        LayoutParams lpStatus = new LayoutParams(statusRowSpec, statusColumnSpec);

        // statusView's characteristics
        statusView.setLayoutParams(lpStatus);
        statusView.setHint("STATUS");
        statusView.setWidth(w + 1500);
        statusView.setTextSize(40);
        statusView.setGravity(Gravity.CENTER);
        statusView.setBackgroundColor(Color.YELLOW);
        statusView.setTextColor(Color.BLACK);

        //Adding the Views
        addView(checkButton);
        addView(emailField);
        addView(statusView);

    }

    /**
     * Retrieves the current text from the emailField EditText
     *
     * @return A string representing the current text in the emailField
     */
    public String getEmail() {return emailField.getText().toString();}

    /**
     * Updates the text of the statusView TextView with the provided message
     *
     * @param text: The message or status to display in the statusView
     */
    public void setStatusText(String text) { statusView.setText(text);}
}
