package edu.niu.android.sqlliteandcontactslist;

/************************************************************************
 *                                                                      *
 * CSCI 322/522 Assignment 6 Fall semester                              *
 *                                                                      *
 * App Name: SQL Lite and Contacts List                                 *
 *                                                                      *
 * Class Name: DatabaseManager.java                                     *
 *                                                                      *
 * Developer(s): Terry Kucala & Jake Kurbis                             *
 *                                                                      *
 * Due Date: 11/17/2023                                                 *
 *                                                                      *
 * Purpose: Manages database operations for contacts, including         *
 *          creation, updates, deletions, and queries.                  *
 *                                                                      *
 ************************************************************************/

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DatabaseManager extends SQLiteOpenHelper {
    //Database configuration constants
    private static final String DATABASE_NAME = "contactsDB";//Name of the database
    private static final int DATABASE_VERSION = 1;           //Version of the database
    private static final String TABLE_CONTACTS = "contacts"; //Name of the table to store contacts
    private static final String ID = "id";                   //Column name for ID
    private static final String FIRST_NAME = "first_name";   //Column name for first name
    private static final String LAST_NAME = "last_name";     //Column name for last name
    private static final String EMAIL = "email";             // Column name for email
    private static final String PHONE_NUMBER = "phone_number";// Column name for phone number

    //Constructor to initialize the database manager
    public DatabaseManager(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    //Called when the database is created for the first time
    @Override
    public void onCreate(SQLiteDatabase db) {
        //SQL statement to create a new contacts table
        String sqlCreate = "create table " + TABLE_CONTACTS + "(" + ID;
        sqlCreate += " Integer primary key autoincrement, " + FIRST_NAME;
        sqlCreate += " text, " + LAST_NAME + " text, " + EMAIL + " text, ";
        sqlCreate += PHONE_NUMBER + " long)";
        db.execSQL(sqlCreate);//Execute the SQL statement to create the table
    }

    //Called when the database needs to be upgraded
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //Drop the existing contacts table if it exists
        db.execSQL("drop table if exists " + TABLE_CONTACTS);
        //Recreate the table
        onCreate(db);
    }

    //Inserts a new contact into the database
    public void insert(Contact contact) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(FIRST_NAME, contact.getFirstName());
        values.put(LAST_NAME, contact.getLastName());
        values.put(EMAIL, contact.getEmail());
        values.put(PHONE_NUMBER, contact.getPhoneNumber());
        db.insert(TABLE_CONTACTS, null, values);//Insert the values into the table
        db.close();//Close the database connection
    }

    //Deletes a contact by ID
    public void deleteById(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        String sqlDelete = "delete from " + TABLE_CONTACTS + " where " + ID + " = " + id;
        db.execSQL(sqlDelete);//Execute the SQL statement to delete the contact
        db.close();//Close the database connection
    }

    //Updates a contact by ID
    public void updateById(int id, String firstName, String lastName, String email, long phoneNumber) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(FIRST_NAME, firstName);
        values.put(LAST_NAME, lastName);
        values.put(EMAIL, email);
        values.put(PHONE_NUMBER, phoneNumber);
        db.update(TABLE_CONTACTS, values, ID + " = ?", new String[]{String.valueOf(id)});// Update the contact
        db.close();//Close the database connection
    }

    //Selects all contacts from the database
    public ArrayList<Contact> selectAllContacts() {
        ArrayList<Contact> contacts = new ArrayList<>();
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from " + TABLE_CONTACTS, null);
        while (cursor.moveToNext()) {
            @SuppressLint("Range") Contact contact = new Contact(
                    cursor.getInt(cursor.getColumnIndex(ID)),
                    cursor.getString(cursor.getColumnIndex(FIRST_NAME)),
                    cursor.getString(cursor.getColumnIndex(LAST_NAME)),
                    cursor.getString(cursor.getColumnIndex(EMAIL)),
                    cursor.getLong(cursor.getColumnIndex(PHONE_NUMBER))
            );
            contacts.add(contact);//Add the contact to the list
        }
        cursor.close();//Close the cursor
        db.close();//Close the database connection
        return contacts;//Return the list of contacts
    }

    //Retrieves all emails from the contacts
    public ArrayList<String> getAllEmails() {
        ArrayList<String> emailList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT " + EMAIL + " FROM " + TABLE_CONTACTS;
        Cursor cursor = db.rawQuery(query, null);
        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") String email = cursor.getString(cursor.getColumnIndex(EMAIL));
                emailList.add(email);//Add the email to the list
            } while (cursor.moveToNext());
        }
        cursor.close();//Close the cursor
        db.close();//Close the database connection
        return emailList;//Return the list of emails
    }

    //Selects a contact by email
    @SuppressLint("Range")
    public Contact selectContactByEmail(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_CONTACTS + " WHERE " + EMAIL + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{email});
        Contact contact = null;
        if (cursor.moveToFirst()) {
            contact = new Contact(
                    cursor.getInt(cursor.getColumnIndex(ID)),
                    cursor.getString(cursor.getColumnIndex(FIRST_NAME)),
                    cursor.getString(cursor.getColumnIndex(LAST_NAME)),
                    cursor.getString(cursor.getColumnIndex(EMAIL)),
                    cursor.getLong(cursor.getColumnIndex(PHONE_NUMBER))
            );
        }
        cursor.close();//Close the cursor
        db.close();//Close the database connection
        return contact;//Return the contact
    }
}