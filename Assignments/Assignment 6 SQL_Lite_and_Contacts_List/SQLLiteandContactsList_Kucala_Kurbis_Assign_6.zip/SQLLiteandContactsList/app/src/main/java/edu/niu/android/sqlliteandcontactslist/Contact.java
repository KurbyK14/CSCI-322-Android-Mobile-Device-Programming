package edu.niu.android.sqlliteandcontactslist;

/************************************************************************
 *                                                                      *
 * CSCI 322/522 Assignment 6 Fall semester                              *
 *                                                                      *
 * App Name: SQL Lite and Contacts List                                 *
 *                                                                      *
 * Class Name: Contact.java                                             *
 *                                                                      *
 * Developer(s): Terry Kucala & Jake Kurbis                             *
 *                                                                      *
 * Due Date: 11/17/2023                                                 *
 *                                                                      *
 * Purpose: Manages contact details (ID, name, email, phone) for the    *
 *          app's database and UI. Provides data access and formatting  *
 *          methods for efficient contact information handling.         *
 *                                                                      *
 ************************************************************************/


public class Contact {
    private int id;             // Unique identifier for each contact.
    private String firstName;   // First name of the contact.
    private String lastName;    // Last name of the contact.
    private String email;       // Email address of the contact.
    private long phoneNumber;   // Phone number of the contact, stored as a long.

    // Constructor for the Contact class. It initializes a new instance of Contact with given values.
    public Contact(int id, String firstName, String lastName, String email, long phoneNumber) {
        this.id = id;                   // Sets the contact's id.
        this.firstName = firstName;     // Sets the contact's first name.
        this.lastName = lastName;       // Sets the contact's last name.
        this.email = email;             // Sets the contact's email.
        this.phoneNumber = phoneNumber; // Sets the contact's phone number.
    }

    // Get method for the contact's ID.
    public int getID() {
        return id; // Returns the contact's ID.
    }

    // Get method for the contact's first name.
    public String getFirstName() {
        return firstName; // Returns the contact's first name.
    }

    // Get method for the contact's last name.
    public String getLastName() {
        return lastName; // Returns the contact's last name.
    }

    // Get method for the contact's email.
    public String getEmail() {
        return email; // Returns the contact's email.
    }

    // Get method for the contact's phone number.
    public long getPhoneNumber() {
        return phoneNumber; // Returns the contact's phone number.
    }

    // Override the toString() method to provide a string representation of the Contact object.
    @Override
    public String toString() {
        String formattedPhoneNumber;

        // Convert the phone number from long to String.
        String PhoneNumber = String.valueOf(phoneNumber);

        // Check if the phone number is 10 digits long (typical for US numbers).
        if (PhoneNumber.length() == 10) {
            // If it is, format it with dashes (xxx-xxx-xxxx).
            formattedPhoneNumber = String.format("%s-%s-%s",
                    PhoneNumber.substring(0, 3),
                    PhoneNumber.substring(3, 6),
                    PhoneNumber.substring(6, 10));
        } else {
            // If the phone number is not 10 digits, keep it in its original form.
            formattedPhoneNumber = PhoneNumber;
        }

        // Return a string representation of the Contact, including name, email, and formatted phone number.
        return firstName + " " + lastName + "\n" +
                "Email: " + email + "\n" +
                "Phone: " + formattedPhoneNumber;
    }
}