package edu.niu.android.sqlliteandcontactslist;

/************************************************************************
 *                                                                      *
 * CSCI 322/522 Assignment 6 Fall semester                              *
 *                                                                      *
 * App Name: SQLiteAndConctactsList                                     *
 *                                                                      *
 * Class Name: UpdateActivity.java                                      *
 *                                                                      *
 * Developer(s): Terry Kucala & Jake Kurbis                             *
 *                                                                      *
 * Due Date: 11/17/2023                                                 *
 *                                                                      *
 * Purpose: This activity allows the database contacts to be edited     *
 *           by the user and updates the necessary text fields          *
 *                                                                      *
 ************************************************************************/

import android.graphics.Point;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ScrollView;
import android.widget.Toast;

import java.util.ArrayList;

public class UpdateActivity extends AppCompatActivity {
    DatabaseManager dbManager;

    // Called when the activity is created
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dbManager = new DatabaseManager(this);
        updateView(); // Calls the method to update the view
    }

    // Builds a View dynamically with all the contacts
    public void updateView() {
        ArrayList<Contact> contacts = dbManager.selectAllContacts();
        if (contacts.size() > 0) {
            ScrollView scrollView = new ScrollView(this);
            GridLayout grid = new GridLayout(this);
            // 4 Rows
            grid.setRowCount(contacts.size() * 4);
            // 2 Columns
            grid.setColumnCount(2);

            // Retrieve width of screen
            Point size = new Point();
            getWindowManager().getDefaultDisplay().getSize(size);
            int width = size.x;

            int row = 0;
            for (Contact contact : contacts) {
                // EditTexts for contact details
                EditText[] contactDetails = new EditText[4];
                contactDetails[0] = new EditText(this); // First Name
                contactDetails[1] = new EditText(this); // Last Name
                contactDetails[2] = new EditText(this); // Email
                contactDetails[3] = new EditText(this); // Phone Number

                // Set texts and IDs for EditTexts
                contactDetails[0].setText(contact.getFirstName());
                contactDetails[1].setText(contact.getLastName());
                contactDetails[2].setText(contact.getEmail());
                contactDetails[3].setText("" + contact.getPhoneNumber());
                contactDetails[3].setInputType(InputType.TYPE_CLASS_PHONE);
                for (int j = 0; j < 4; j++) {
                    contactDetails[j].setId(10 * contact.getID() + j);
                    GridLayout.LayoutParams detailParams = new GridLayout.LayoutParams();
                    detailParams.columnSpec = GridLayout.spec(0);
                    detailParams.rowSpec = GridLayout.spec(row + j);
                    detailParams.width = (int) (width * 0.7);
                    grid.addView(contactDetails[j], detailParams);
                }

                // Button for updating
                Button updateButton = new Button(this);
                updateButton.setText(R.string.update);
                updateButton.setTextSize(20);
                updateButton.setId(contact.getID());
                updateButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // Retrieve the contact's details
                        int contactId = v.getId();
                        EditText firstNameET = (EditText) findViewById(10 * contactId);
                        EditText lastNameET = (EditText) findViewById(10 * contactId + 1);
                        EditText emailET = (EditText) findViewById(10 * contactId + 2);
                        EditText phoneET = (EditText) findViewById(10 * contactId + 3);
                        String firstName = firstNameET.getText().toString();
                        String lastName = lastNameET.getText().toString();
                        String email = emailET.getText().toString();
                        String phoneString = phoneET.getText().toString();

                        // Update contact in database
                        try {
                            long phoneNumber = Long.parseLong(phoneString);
                            dbManager.updateById(contactId, firstName, lastName, email, phoneNumber);
                            Toast.makeText(UpdateActivity.this, "CONTACT UPDATED", Toast.LENGTH_LONG).show();
                            // Update screen
                            updateView();
                        } catch (NumberFormatException nfe) {
                            Toast.makeText(UpdateActivity.this, "Phone Number Error", Toast.LENGTH_LONG).show();
                        }
                    }
                });
                GridLayout.LayoutParams buttonParams = new GridLayout.LayoutParams();
                buttonParams.columnSpec = GridLayout.spec(1);
                buttonParams.rowSpec = GridLayout.spec(row, 4);
                buttonParams.width = (int) (width * 0.3);
                buttonParams.setGravity(Gravity.END);
                grid.addView(updateButton, buttonParams);

                // Move to next set of rows for next contact
                row += 4;
            }
            scrollView.addView(grid);
            setContentView(scrollView);
        }
    }
}