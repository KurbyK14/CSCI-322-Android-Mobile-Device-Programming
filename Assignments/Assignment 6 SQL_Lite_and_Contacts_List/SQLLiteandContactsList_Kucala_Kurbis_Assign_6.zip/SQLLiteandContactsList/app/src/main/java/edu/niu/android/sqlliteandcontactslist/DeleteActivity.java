package edu.niu.android.sqlliteandcontactslist;

/************************************************************************
 *                                                                      *
 * CSCI 322/522 Assignment 6 Fall semester                              *
 *                                                                      *
 * App Name: SQL Lite and Contacts List                                 *
 *                                                                      *
 * Class Name: DeleteActivity.java                                      *
 *                                                                      *
 * Developer(s): Terry Kucala & Jake Kurbis                             *
 *                                                                      *
 * Due Date: 11/17/2023                                                 *
 *                                                                      *
 * Purpose: This class provides the functionality for the Delete        *
 *          Activity in the app. It allows users to delete contacts     *
 *          from the database.                                          *
 *                                                                      *
 ************************************************************************/

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Toast;

import java.util.ArrayList;

public class DeleteActivity extends AppCompatActivity {
    private DatabaseManager dbManager;//Instance of DatabaseManager to handle database operations

    //onCreate is called when the activity is starting
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dbManager = new DatabaseManager(this);//Initialize the DatabaseManager
        updateView();//Call updateView to set up the UI
    }

    //Dynamically creates the view with all the records from the database
    public void updateView() {
        ArrayList<Contact> contacts = dbManager.selectAllContacts();//Retrieve all contacts
        RelativeLayout layout = new RelativeLayout(this);//Create a RelativeLayout
        ScrollView scrollView = new ScrollView(this);//Create a ScrollView to allow scrolling
        RadioGroup group = new RadioGroup(this);//Create a RadioGroup for radio buttons

        //Loop through each contact and create a radio button for it
        for (Contact contact : contacts) {
            RadioButton rb = new RadioButton(this);
            rb.setId(contact.getID());//Set the ID of the radio button to the contact's ID
            rb.setText(contact.toString());//Set the text of the radio button to the contact's details
            group.addView(rb);//Add the radio button to the RadioGroup
        }

        //Set up event handling for the RadioGroup
        RadioButtonHandler rbh = new RadioButtonHandler();
        group.setOnCheckedChangeListener(rbh);

        //Create a back button to return to the previous screen
        Button backButton = new Button(this);
        backButton.setText(R.string.button_back);
        backButton.setOnClickListener(v -> DeleteActivity.this.finish());
        //Set onClickListener to finish the activity

        scrollView.addView(group);//Add the RadioGroup to the ScrollView
        layout.addView(scrollView);//Add the ScrollView to the RelativeLayout

        //Add the back button to the bottom of the RelativeLayout
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT);
        params.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        params.addRule(RelativeLayout.CENTER_HORIZONTAL);
        params.setMargins(0, 0, 0, 50);
        layout.addView(backButton, params);

        setContentView(layout);//Set the RelativeLayout as the content view of the activity
    }

    //Inner class to handle radio button selection events
    private class RadioButtonHandler implements RadioGroup.OnCheckedChangeListener {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            dbManager.deleteById(checkedId);//Delete the selected contact from the database
            Toast.makeText(DeleteActivity.this, "Contact deleted", Toast.LENGTH_SHORT).show();
            //Show a toast message

            updateView();//Update the view to reflect the deletion
        }
    }
}