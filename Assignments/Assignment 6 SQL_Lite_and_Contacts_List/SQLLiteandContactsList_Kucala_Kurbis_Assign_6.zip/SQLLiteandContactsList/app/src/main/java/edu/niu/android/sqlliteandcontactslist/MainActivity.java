package edu.niu.android.sqlliteandcontactslist;

/************************************************************************
 *                                                                      *
 * CSCI 322/522 Assignment 6 Fall semester                              *
 *                                                                      *
 * App Name: SQLiteAndConctactsList                                     *
 *                                                                      *
 * Class Name: MainActivity.java                                        *
 *                                                                      *
 * Developer(s): Terry Kucala & Jake Kurbis                             *
 *                                                                      *
 * Due Date: 11/17/2023                                                 *
 *                                                                      *
 * Purpose: This activity creates the main view of the application.     *
 *           It creates icons on the activity bar that allows a user to *
 *           add a contact, delete a contact or edit contacts.          *
 *           It also allows the user to see all contacts or search      *
 *           contacts by email.                                         *
 *                                                                      *
 ************************************************************************/

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.content.Intent;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ListView;
import android.widget.Toast;
import android.text.Editable;
import android.text.TextWatcher;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private DatabaseManager dbManager;
    private ListView contactsListView;
    private AutoCompleteTextView searchEmail;
    private ArrayAdapter<Contact> adapter;
    private ArrayAdapter<String> searchAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize database manager and UI elements
        dbManager = new DatabaseManager(this);
        contactsListView = findViewById(R.id.contactsListView);
        searchEmail = findViewById(R.id.searchEmail);

        updateView();
        setupSearchView();
    }

    // Updates the UI when the activity resumes
    @Override
    protected void onResume() {
        super.onResume();
        updateView();
    }

    // Updates the UI based on search input or displays all contacts
    public void updateView() {
        String enteredEmail = searchEmail.getText().toString().trim();

        // If search box is not empty
        if (!enteredEmail.isEmpty()) {
            Contact contact = dbManager.selectContactByEmail(enteredEmail);

            // Display single contact if found
            if (contact != null) {
                ArrayList<Contact> singleContactList = new ArrayList<>();
                singleContactList.add(contact);

                adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, singleContactList);
                contactsListView.setAdapter(adapter);
            }
            // Clear list view if contact not found
            else {
                contactsListView.setAdapter(null);
            }
        }
        // If search box is empty, display all contacts
        else {
            ArrayList<Contact> contacts = dbManager.selectAllContacts();
            if (contacts != null) {
                adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, contacts);
                contactsListView.setAdapter(adapter);
            }
        }
    }

    // Sets up the search functionality using AutoCompleteTextView
    private void setupSearchView() {
        ArrayList<String> emailList = dbManager.getAllEmails();
        searchAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, emailList);

        searchEmail.setAdapter(searchAdapter);
        searchEmail.setThreshold(1);

        // Adding a TextWatcher to monitor changes in the search box
        searchEmail.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                String enteredEmail = editable.toString().trim();

                // Show all contacts if search box is empty
                if (enteredEmail.isEmpty()) {
                    updateView();
                } else {
                    // Show contacts matching entered email
                    Contact contact = dbManager.selectContactByEmail(enteredEmail);

                    // Display single contact if found
                    if (contact != null) {
                        ArrayList<Contact> singleContactList = new ArrayList<>();
                        singleContactList.add(contact);

                        adapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, singleContactList);
                        contactsListView.setAdapter(adapter);

                        Toast.makeText(MainActivity.this, "Contact: " + contact.getFirstName() +
                                " " + contact.getLastName(), Toast.LENGTH_LONG).show();
                    }
                    // Clear list view if contact not found
                    else {
                        contactsListView.setAdapter(null);
                    }
                }
            }
        });
    }

    // Inflate the activity bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    // Handle buttons on activity bar
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        // add contact
        if (id == R.id.action_add) {
            Log.w("MainActivity", "Add selected");
            Intent insertIntent = new Intent(this, InsertActivity.class);
            this.startActivity(insertIntent);
            return true;
        }
        // delete contact
        else if (id == R.id.action_delete) {
            Intent deleteIntent = new Intent(this, DeleteActivity.class);
            this.startActivity(deleteIntent);
            return true;
        }
        // update contact
        else if (id == R.id.action_update) {
            Intent updateIntent = new Intent(this, UpdateActivity.class);
            this.startActivity(updateIntent);
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }
}