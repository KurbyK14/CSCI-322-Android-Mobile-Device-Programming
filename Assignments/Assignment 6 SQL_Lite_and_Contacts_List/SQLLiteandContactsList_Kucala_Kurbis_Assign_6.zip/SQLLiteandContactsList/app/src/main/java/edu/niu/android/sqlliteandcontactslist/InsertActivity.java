package edu.niu.android.sqlliteandcontactslist;

/************************************************************************
 *                                                                      *
 * CSCI 322/522 Assignment 6 Fall semester                              *
 *                                                                      *
 * App Name: SQLiteAndConctactsList                                     *
 *                                                                      *
 * Class Name: InsertActivity.java                                      *
 *                                                                      *
 * Developer(s): Terry Kucala & Jake Kurbis                             *
 *                                                                      *
 * Due Date: 11/17/2023                                                 *
 *                                                                      *
 * Purpose: This activity handles adding a new contact into the db.     *
 *           It allows a user to enter first name, last name, email,    *
 *           and phone number. The user then selects add to add the     *
 *           contact to the db or back to go back home.                 *
 *                                                                      *
 ************************************************************************/

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class InsertActivity extends AppCompatActivity
{
    private DatabaseManager dbManager;

    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        dbManager = new DatabaseManager(this);
        setContentView(R.layout.activity_insert);
    }

    // create the view for creating a contact and updating the db
    public void insert(View v)
    {
        // Retrieve contact details
        EditText firstNameEditText = (EditText) findViewById(R.id.input_first_name);
        EditText lastNameEditText = (EditText) findViewById(R.id.input_last_name);
        EditText emailEditText = (EditText) findViewById(R.id.input_email);
        EditText phoneNumberEditText = (EditText) findViewById(R.id.input_phone_number);

        String firstName = firstNameEditText.getText().toString();
        String lastName = lastNameEditText.getText().toString();
        String email = emailEditText.getText().toString();
        String phoneNumberString = phoneNumberEditText.getText().toString();

        // insert new contact in database
        try
        {
            long phoneNumber = Long.parseLong(phoneNumberString);
            Contact contact = new Contact(0, firstName, lastName, email, phoneNumber);
            dbManager.insert(contact);
            Toast.makeText(this, "Contact added", Toast.LENGTH_SHORT).show();
        }
        // if phone number is entered wrong
        catch(NumberFormatException nfe)
        {
            Toast.makeText(this, "Phone Number error", Toast.LENGTH_LONG).show();
        }

        // clear data
        firstNameEditText.setText("");
        lastNameEditText.setText("");
        emailEditText.setText("");
        phoneNumberEditText.setText("");
    }

    // go back home
    public void goBack(View v)
    {
        this.finish();
    }
}
