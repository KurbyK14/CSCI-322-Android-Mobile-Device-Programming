package edu.niu.android.additionapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

/************************************************************************
 *                                                                      *
 * CSCI 322/522 Assignment 3 Part 2 Fall semester                       *
 *                                                                      *
 * App Name: Addition App                                               *
 *                                                                      *
 * Class Name: MainActivity.java                                        *
 *                                                                      *
 * Developer(s): Terry Kucala & Jake Kurbis                             *
 *                                                                      *
 * Due Date: 10/06/2023                                                 *
 *                                                                      *
 * Purpose: MainActivity class serves as a controller in the            *
 *          application, mediating the interaction between the user     *
 *          interface and the AddCalculator model.                      *
 *                                                                      *
 ************************************************************************/

public class MainActivity extends AppCompatActivity
{
    // Instance of AddCalculator to perform addition
    private AddCalculator addCalc;

    /**
     * onCreate method initializes the activity and the AddCalculator instance. As well as,
     * sets the initial content view of the activity
     *
     * @param savedInstanceState is a Bundle object containing the activity's previous saved state
     *
     */
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        addCalc = new AddCalculator((int)0.17f, (int)100.0f);
        setContentView(R.layout.activity_main);

    }

    /**
     * calculate() method is triggered when the user presses the calulate button. it retrieves the
     * numbers entered by the user, instructs AddCalculator to perform addition and displays the
     * result or an error message in case of invalid input
     *
     * @param v is the View that was clicked
     */
    public void calculate(View v)
    {
        // Gets user inputs from UI
        EditText FirstNumEditText = (EditText) findViewById(R.id.FirstEditText);
        EditText SecondNumEditText = (EditText) findViewById(R.id.SecondEditText);

        String numOneString = FirstNumEditText.getText().toString();
        String numTwoString = SecondNumEditText.getText().toString();

        // Reference from TextView to update the result
        TextView sumTextView = (TextView) findViewById(R.id.sum_amount);

        try
        {
            // convert numOneString and numTwoString to integers
            int numOneInt = Integer.parseInt(numOneString);
            int numTwoInt = Integer.parseInt(numTwoString);

            // update the Model
            addCalc.setNumOne(numOneInt);
            addCalc.setNumTwo(numTwoInt);

            // ask Model to calculate sum amount of the two integers
            int sum = addCalc.sumAmount();

            // Display the result in the TextView
            sumTextView.setText(String.valueOf(sum));

        }
        catch(NumberFormatException nfe)
        {
            // If the user puts in non-integers, this error will pop up
            sumTextView.setText("Invalid input, please enter valid integers!");
        }
    }
}