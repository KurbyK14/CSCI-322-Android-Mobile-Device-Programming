package edu.niu.android.additionapp;

/************************************************************************
 *                                                                      *
 * CSCI 322/522 Assignment 3 Part 2 Fall semester                       *
 *                                                                      *
 * App Name: Addition App                                               *
 *                                                                      *
 * Class Name: AddCalculator.java                                       *
 *                                                                      *
 * Developer(s): Terry Kucala & Jake Kurbis                             *
 *                                                                      *
 * Due Date: 10/06/2023                                                 *
 *                                                                      *
 * Purpose: The AddCalculator class provides methods for adding two     *
 *          integer values. It allows setting and retrieving individual *
 *          operands, and can compute the sum of these operands using   *
 *          the sumAmount() method.                                     *
 *                                                                      *
 ************************************************************************/

public class AddCalculator
{
    // First number to be added
    private int numOne;
    // Second number to be added
    private int numTwo;

    // Constructor that initializes numOne and numTwo
    public AddCalculator(int numOne, int numTwo)
    {
        setNumOne(numOne);
        setNumTwo(numTwo);
    }

    // Returns the value of numOne
    public int getNumOne()
    {
        return numOne;
    }

    // Returns the value of numTwo
    public int getNumTwo()
    {
        return numTwo;
    }

    // Sets the value of numOne to the provided user input
    public void setNumOne(int numOne)
    {
        this.numOne = numOne;
    }

    // Sets the value of numTwo to the provided user input
    public void setNumTwo(int numTwo)
    {
        this.numTwo = numTwo;
    }

    // Returns the sum of numOne and numTwo
    public int sumAmount()
    {
        return numOne + numTwo;
    }
}